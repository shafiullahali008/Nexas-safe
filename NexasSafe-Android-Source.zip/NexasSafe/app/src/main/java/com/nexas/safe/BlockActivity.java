package com.nexas.safe;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class BlockActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Window window = getWindow();
        window.setStatusBarColor(Color.rgb(16, 24, 39));
        window.setNavigationBarColor(Color.rgb(16, 24, 39));
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(28), dp(36), dp(28), dp(36));
        root.setBackgroundColor(Color.rgb(16, 24, 39));

        TextView shield = new TextView(this);
        shield.setText("◆");
        shield.setTextColor(Color.rgb(74, 222, 128));
        shield.setTextSize(48);
        shield.setGravity(Gravity.CENTER);
        root.addView(shield, matchWrap());

        TextView brand = new TextView(this);
        brand.setText("NEXAS SAFE");
        brand.setTextColor(Color.WHITE);
        brand.setTextSize(15);
        brand.setLetterSpacing(0.18f);
        brand.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        brand.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams brandLp = matchWrap();
        brandLp.bottomMargin = dp(28);
        root.addView(brand, brandLp);

        TextView status = new TextView(this);
        status.setText("CONTENT BLOCKED");
        status.setTextColor(Color.rgb(74, 222, 128));
        status.setTextSize(11);
        status.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        status.setLetterSpacing(0.12f);
        status.setGravity(Gravity.CENTER);
        GradientDrawable pill = new GradientDrawable();
        pill.setColor(Color.rgb(25, 61, 49));
        pill.setCornerRadius(dp(30));
        pill.setStroke(dp(1), Color.rgb(34, 110, 74));
        status.setBackground(pill);
        status.setPadding(dp(15), dp(9), dp(15), dp(9));
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(-2, -2);
        statusLp.bottomMargin = dp(24);
        root.addView(status, statusLp);

        TextView heading = new TextView(this);
        heading.setText("Stay pure.");
        heading.setTextColor(Color.WHITE);
        heading.setTextSize(30);
        heading.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        heading.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams headingLp = matchWrap();
        headingLp.bottomMargin = dp(12);
        root.addView(heading, headingLp);

        TextView message = new TextView(this);
        message.setText("This content has been blocked to protect your focus.");
        message.setTextColor(Color.rgb(203, 213, 225));
        message.setTextSize(16);
        message.setGravity(Gravity.CENTER);
        message.setLineSpacing(dp(4), 1f);
        LinearLayout.LayoutParams messageLp = new LinearLayout.LayoutParams(-1, -2);
        messageLp.bottomMargin = dp(34);
        root.addView(message, messageLp);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(18), dp(18), dp(18), dp(18));
        GradientDrawable cardBg = new GradientDrawable();
        cardBg.setColor(Color.rgb(30, 41, 59));
        cardBg.setCornerRadius(dp(18));
        card.setBackground(cardBg);
        TextView cardTitle = new TextView(this);
        cardTitle.setText("PROTECTION STATUS                         ACTIVE");
        cardTitle.setTextColor(Color.rgb(74, 222, 128));
        cardTitle.setTextSize(11);
        cardTitle.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        card.addView(cardTitle);
        TextView cardBody = new TextView(this);
        cardBody.setText("Your focus matters.");
        cardBody.setTextColor(Color.WHITE);
        cardBody.setTextSize(16);
        cardBody.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        LinearLayout.LayoutParams bodyLp = matchWrap();
        bodyLp.topMargin = dp(12);
        card.addView(cardBody, bodyLp);
        TextView cardSub = new TextView(this);
        cardSub.setText("Take a breath. Return to what matters most.");
        cardSub.setTextColor(Color.rgb(148, 163, 184));
        cardSub.setTextSize(13);
        LinearLayout.LayoutParams subLp = matchWrap();
        subLp.topMargin = dp(5);
        card.addView(cardSub, subLp);
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(-1, -2);
        cardLp.bottomMargin = dp(28);
        root.addView(card, cardLp);

        Button button = new Button(this);
        button.setText("RETURN TO SAFETY");
        button.setTextColor(Color.WHITE);
        button.setTextSize(14);
        button.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        button.setAllCaps(false);
        GradientDrawable buttonBg = new GradientDrawable();
        buttonBg.setColor(Color.rgb(22, 163, 74));
        buttonBg.setCornerRadius(dp(14));
        button.setBackground(buttonBg);
        button.setPadding(dp(12), dp(10), dp(12), dp(10));
        button.setOnClickListener(v -> goHome());
        root.addView(button, new LinearLayout.LayoutParams(-1, dp(54)));

        TextView footer = new TextView(this);
        footer.setText("PROTECTED BY NEXAS SAFE");
        footer.setTextColor(Color.rgb(100, 116, 139));
        footer.setTextSize(10);
        footer.setLetterSpacing(0.12f);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams footerLp = matchWrap();
        footerLp.topMargin = dp(24);
        root.addView(footer, footerLp);

        setContentView(root);
    }

    private void goHome() {
        Intent home = new Intent(Intent.ACTION_MAIN);
        home.addCategory(Intent.CATEGORY_HOME);
        home.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(home);
        finish();
    }

    @Override
    public void onBackPressed() {
        goHome();
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(-1, -2);
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}

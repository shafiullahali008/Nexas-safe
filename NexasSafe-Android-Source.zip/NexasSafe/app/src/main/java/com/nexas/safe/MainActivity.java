package com.nexas.safe;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQUEST_ADMIN = 410;
    private final Handler handler = new Handler();
    private TextView focusStatus;
    private TextView accessibilityStatus;
    private TextView adminStatus;
    private EditText packageInput;
    private long selectedDurationMs = 60L * 60L * 1000L;
    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            refreshStatuses();
            handler.postDelayed(this, 1000L);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(16, 24, 39));
        getWindow().setNavigationBarColor(Color.rgb(16, 24, 39));
        buildUi();
    }

    @Override protected void onResume() {
        super.onResume();
        refreshStatuses();
        handler.removeCallbacks(ticker);
        handler.post(ticker);
    }

    @Override protected void onPause() {
        super.onPause();
        handler.removeCallbacks(ticker);
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(26), dp(20), dp(30));
        root.setBackgroundColor(Color.rgb(16, 24, 39));
        scroll.addView(root);

        TextView brand = text("NEXAS SAFE", 13, Color.rgb(74, 222, 128), true);
        brand.setLetterSpacing(0.16f);
        root.addView(brand);

        TextView title = text("Protect your focus.", 29, Color.WHITE, true);
        LinearLayout.LayoutParams titleLp = fullWrap(); titleLp.topMargin = dp(10);
        root.addView(title, titleLp);

        TextView intro = text("Local content checks and timed app restrictions. Screen text stays on this device.", 14, Color.rgb(148, 163, 184), false);
        LinearLayout.LayoutParams introLp = fullWrap(); introLp.topMargin = dp(8); introLp.bottomMargin = dp(22);
        root.addView(intro, introLp);

        LinearLayout protectionCard = card();
        protectionCard.addView(text("PROTECTION", 11, Color.rgb(148, 163, 184), true));
        accessibilityStatus = text("Accessibility: checking…", 15, Color.WHITE, true);
        LinearLayout.LayoutParams s1 = fullWrap(); s1.topMargin = dp(13); protectionCard.addView(accessibilityStatus, s1);
        Button accessibilityButton = button("ENABLE ACCESSIBILITY SERVICE");
        LinearLayout.LayoutParams ab = fullWidth(); ab.topMargin = dp(12); protectionCard.addView(accessibilityButton, ab);
        accessibilityButton.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        adminStatus = text("Device Admin: checking…", 14, Color.rgb(203, 213, 225), false);
        LinearLayout.LayoutParams s2 = fullWrap(); s2.topMargin = dp(15); protectionCard.addView(adminStatus, s2);
        Button adminButton = button("ENABLE DEVICE ADMIN (OPTIONAL)");
        LinearLayout.LayoutParams adb = fullWidth(); adb.topMargin = dp(10); protectionCard.addView(adminButton, adb);
        adminButton.setOnClickListener(v -> requestDeviceAdmin());
        TextView privacy = text("Accessibility permission can read visible text in other apps. Nexas Safe checks it locally and does not save or upload it. Android users can turn this permission off in Settings.", 12, Color.rgb(148, 163, 184), false);
        LinearLayout.LayoutParams pp = fullWrap(); pp.topMargin = dp(12); protectionCard.addView(privacy, pp);
        root.addView(protectionCard);

        LinearLayout focusCard = card();
        LinearLayout.LayoutParams fcLp = fullWrap(); fcLp.topMargin = dp(16); root.addView(focusCard, fcLp);
        focusCard.addView(text("STRICT FOCUS MODE", 11, Color.rgb(148, 163, 184), true));
        focusStatus = text("Focus Mode is OFF", 19, Color.WHITE, true);
        LinearLayout.LayoutParams fs = fullWrap(); fs.topMargin = dp(12); focusCard.addView(focusStatus, fs);
        TextView help = text("Choose a duration. Selected apps will be sent back to the safe screen until the timer ends.", 13, Color.rgb(148, 163, 184), false);
        LinearLayout.LayoutParams hlp = fullWrap(); hlp.topMargin = dp(7); focusCard.addView(help, hlp);

        LinearLayout durationRow1 = new LinearLayout(this); durationRow1.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout durationRow2 = new LinearLayout(this); durationRow2.setOrientation(LinearLayout.HORIZONTAL);
        addDuration(durationRow1, "30 MIN", 30L * 60L * 1000L);
        addDuration(durationRow1, "1 HOUR", 60L * 60L * 1000L);
        addDuration(durationRow1, "3 HOURS", 3L * 60L * 60L * 1000L);
        addDuration(durationRow2, "6 HOURS", 6L * 60L * 60L * 1000L);
        addDuration(durationRow2, "12 HOURS", 12L * 60L * 60L * 1000L);
        LinearLayout.LayoutParams dr1 = fullWidth(); dr1.topMargin = dp(15); focusCard.addView(durationRow1, dr1);
        LinearLayout.LayoutParams dr2 = fullWidth(); dr2.topMargin = dp(8); focusCard.addView(durationRow2, dr2);

        TextView packagesLabel = text("APPS TO BLOCK DURING FOCUS (PACKAGE IDS)", 11, Color.rgb(148, 163, 184), true);
        LinearLayout.LayoutParams pl = fullWrap(); pl.topMargin = dp(18); focusCard.addView(packagesLabel, pl);
        packageInput = new EditText(this);
        packageInput.setText(ProtectionPrefs.prefs(this).getString(ProtectionPrefs.KEY_BLOCKED_PACKAGES, ProtectionPrefs.defaultPackages()));
        packageInput.setTextColor(Color.WHITE);
        packageInput.setHintTextColor(Color.rgb(148, 163, 184));
        packageInput.setHint("com.example.app, com.example.other");
        packageInput.setTextSize(13);
        packageInput.setMinLines(2);
        packageInput.setGravity(Gravity.TOP | Gravity.START);
        packageInput.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
        packageInput.setPadding(dp(12), dp(12), dp(12), dp(12));
        packageInput.setBackground(roundBg(Color.rgb(15, 23, 42), 12, Color.rgb(51, 65, 85)));
        LinearLayout.LayoutParams pilp = fullWidth(); pilp.topMargin = dp(8); focusCard.addView(packageInput, pilp);

        Button startFocus = button("START FOCUS MODE");
        LinearLayout.LayoutParams sf = fullWidth(); sf.topMargin = dp(14); focusCard.addView(startFocus, sf);
        startFocus.setOnClickListener(v -> startFocus());
        TextView note = text("Focus Mode expires automatically. Device Admin adds friction to ordinary uninstalling but is not tamper-proof; the device owner can always revoke permissions or remove the app.", 12, Color.rgb(148, 163, 184), false);
        LinearLayout.LayoutParams nl = fullWrap(); nl.topMargin = dp(13); focusCard.addView(note, nl);

        TextView keywordNote = text("KEYWORD PROTECTION  •  ON-DEVICE", 11, Color.rgb(74, 222, 128), true);
        LinearLayout.LayoutParams kn = fullWrap(); kn.topMargin = dp(18); root.addView(keywordNote, kn);
        TextView limitation = text("Checks text exposed by apps through Android Accessibility. It cannot inspect every image, video, browser canvas or encrypted app view, so keyword blocking is a best-effort filter rather than a complete adult-content detector.", 12, Color.rgb(148, 163, 184), false);
        LinearLayout.LayoutParams ll = fullWrap(); ll.topMargin = dp(7); root.addView(limitation, ll);

        setContentView(scroll);
    }

    private void addDuration(LinearLayout row, String label, long duration) {
        Button b = button(label);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(44), 1f);
        lp.rightMargin = dp(5);
        row.addView(b, lp);
        b.setOnClickListener(v -> {
            selectedDurationMs = duration;
            Toast.makeText(this, label + " selected", Toast.LENGTH_SHORT).show();
        });
    }

    private void startFocus() {
        String raw = packageInput.getText().toString().trim();
        ProtectionPrefs.prefs(this).edit()
                .putString(ProtectionPrefs.KEY_BLOCKED_PACKAGES, raw)
                .putLong(ProtectionPrefs.KEY_FOCUS_UNTIL, System.currentTimeMillis() + selectedDurationMs)
                .apply();
        ((InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(packageInput.getWindowToken(), 0);
        packageInput.clearFocus();
        refreshStatuses();
        Toast.makeText(this, "Strict Focus Mode started", Toast.LENGTH_LONG).show();
    }

    private void requestDeviceAdmin() {
        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
        ComponentName admin = new ComponentName(this, NexasDeviceAdminReceiver.class);
        if (dpm.isAdminActive(admin)) {
            Toast.makeText(this, "Device Admin is already enabled", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent intent = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
        intent.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin);
        intent.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "Optional: makes ordinary removal require deactivating Nexas Safe in Android Settings first. It does not make the app impossible to uninstall.");
        startActivityForResult(intent, REQUEST_ADMIN);
    }

    private void refreshStatuses() {
        if (focusStatus == null) return;
        boolean enabled = isAccessibilityEnabled();
        accessibilityStatus.setText("Accessibility: " + (enabled ? "ENABLED" : "NOT ENABLED"));
        accessibilityStatus.setTextColor(enabled ? Color.rgb(74, 222, 128) : Color.rgb(248, 113, 113));
        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
        boolean admin = dpm.isAdminActive(new ComponentName(this, NexasDeviceAdminReceiver.class));
        adminStatus.setText("Device Admin: " + (admin ? "ENABLED" : "NOT ENABLED"));
        adminStatus.setTextColor(admin ? Color.rgb(74, 222, 128) : Color.rgb(203, 213, 225));
        if (ProtectionPrefs.isFocusActive(this)) {
            long remaining = Math.max(0L, ProtectionPrefs.focusUntil(this) - System.currentTimeMillis());
            long seconds = remaining / 1000L;
            focusStatus.setText(String.format("FOCUS ACTIVE  •  %02d:%02d:%02d remaining", seconds / 3600, (seconds % 3600) / 60, seconds % 60));
            focusStatus.setTextColor(Color.rgb(74, 222, 128));
        } else {
            focusStatus.setText("Focus Mode is OFF");
            focusStatus.setTextColor(Color.WHITE);
        }
    }

    private boolean isAccessibilityEnabled() {
        String enabled = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null) return false;
        String target = new ComponentName(this, ProtectionAccessibilityService.class).flattenToString();
        for (String item : enabled.split(":")) if (target.equalsIgnoreCase(item)) return true;
        return false;
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(17), dp(17), dp(17), dp(17));
        box.setBackground(roundBg(Color.rgb(30, 41, 59), 18, Color.rgb(51, 65, 85)));
        return box;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextColor(Color.WHITE);
        b.setTextSize(12);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setPadding(dp(10), dp(6), dp(10), dp(6));
        b.setBackground(roundBg(Color.rgb(22, 163, 74), 12, Color.rgb(22, 163, 74)));
        return b;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private GradientDrawable roundBg(int color, int radiusDp, int strokeColor) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        d.setStroke(dp(1), strokeColor);
        return d;
    }

    private LinearLayout.LayoutParams fullWrap() { return new LinearLayout.LayoutParams(-1, -2); }
    private LinearLayout.LayoutParams fullWidth() { return new LinearLayout.LayoutParams(-1, dp(48)); }
    private int dp(int value) { return Math.round(value * getResources().getDisplayMetrics().density); }
}

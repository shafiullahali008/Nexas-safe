package com.nexas.safe;

import android.accessibilityservice.AccessibilityService;
import android.content.Intent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;

public class ProtectionAccessibilityService extends AccessibilityService {
    private static final long BLOCK_COOLDOWN_MS = 2500L;
    private long lastBlockAt = 0L;

    // High-intent terms only. This is a starter list, not a complete classifier.
    private static final Pattern ADULT_PATTERN = Pattern.compile(
            "\\b(porn|porno|pornography|xxx|hentai|onlyfans|adult[ -]video|adult[ -]content|" +
            "nudes?|erotic|camgirl|webcam[ -]sex|sex[ -]video)\\b",
            Pattern.CASE_INSENSITIVE | Pattern.UNICODE_CASE);

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        String packageName = event.getPackageName().toString();
        if (packageName.equals(getPackageName())) return;

        boolean focusActive = ProtectionPrefs.isFocusActive(this);
        if (focusActive && ProtectionPrefs.blockedPackages(this).contains(packageName.toLowerCase(Locale.ROOT))) {
            showBlockScreen("focus");
            return;
        }

        if (!ProtectionPrefs.keywordProtectionEnabled(this)) return;
        if (event.getEventType() != AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED &&
                event.getEventType() != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return;

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        try {
            if (containsAdultKeyword(root, 0)) {
                performGlobalAction(GLOBAL_ACTION_BACK);
                showBlockScreen("keyword");
            }
        } finally {
            root.recycle();
        }
    }

    private boolean containsAdultKeyword(AccessibilityNodeInfo node, int depth) {
        if (node == null || depth > 22) return false;
        CharSequence text = node.getText();
        if (text != null && ADULT_PATTERN.matcher(text.toString()).find()) return true;
        CharSequence description = node.getContentDescription();
        if (description != null && ADULT_PATTERN.matcher(description.toString()).find()) return true;
        int count = Math.min(node.getChildCount(), 80);
        for (int i = 0; i < count; i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            if (child != null) {
                boolean match = containsAdultKeyword(child, depth + 1);
                child.recycle();
                if (match) return true;
            }
        }
        return false;
    }

    private void showBlockScreen(String reason) {
        long now = System.currentTimeMillis();
        if (now - lastBlockAt < BLOCK_COOLDOWN_MS) return;
        lastBlockAt = now;
        Intent intent = new Intent(this, BlockActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        intent.putExtra("reason", reason);
        startActivity(intent);
    }

    @Override
    public void onInterrupt() {
        // No persistent screen data is held by this service.
    }
}

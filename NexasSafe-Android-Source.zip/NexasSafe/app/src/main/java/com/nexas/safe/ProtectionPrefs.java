package com.nexas.safe;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

final class ProtectionPrefs {
    static final String PREFS = "nexas_safe_settings";
    static final String KEY_FOCUS_UNTIL = "focus_until";
    static final String KEY_BLOCKED_PACKAGES = "blocked_packages";
    static final String KEY_KEYWORD_PROTECTION = "keyword_protection";

    private ProtectionPrefs() {}

    static SharedPreferences prefs(Context context) {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    static boolean isFocusActive(Context context) {
        long until = prefs(context).getLong(KEY_FOCUS_UNTIL, 0L);
        if (until <= System.currentTimeMillis()) {
            if (until != 0L) prefs(context).edit().putLong(KEY_FOCUS_UNTIL, 0L).apply();
            return false;
        }
        return true;
    }

    static long focusUntil(Context context) {
        return prefs(context).getLong(KEY_FOCUS_UNTIL, 0L);
    }

    static Set<String> blockedPackages(Context context) {
        String raw = prefs(context).getString(KEY_BLOCKED_PACKAGES, defaultPackages());
        Set<String> result = new HashSet<>();
        if (raw == null) return result;
        for (String item : raw.split("[,\\n; ]+")) {
            String pkg = item.trim().toLowerCase(Locale.ROOT);
            if (pkg.matches("[a-z0-9_]+(\\.[a-z0-9_]+)+")) result.add(pkg);
        }
        return result;
    }

    static String defaultPackages() {
        return "com.instagram.android, com.zhiliaoapp.musically, com.google.android.youtube, " +
                "com.facebook.katana, com.twitter.android";
    }

    static boolean keywordProtectionEnabled(Context context) {
        return prefs(context).getBoolean(KEY_KEYWORD_PROTECTION, true);
    }
}

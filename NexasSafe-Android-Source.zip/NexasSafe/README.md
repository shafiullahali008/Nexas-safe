# Nexas Safe — Android starter project

A native Android starter app containing:

- The requested strict warning screen: **“Stay pure.”** / **“This content has been blocked to protect your focus.”** / **“RETURN TO SAFETY”**.
- Local keyword matching against text exposed by Android Accessibility nodes.
- Timed Focus Mode that sends configured app packages to the warning screen.
- Optional Android Device Admin activation, with an explanation of its limits.
- No analytics, accounts, cloud services, or network permission. Screen text is not saved or uploaded.

## Build an APK

1. Install Android Studio on a computer and the Android SDK Platform 35.
2. Open this `NexasSafe` folder in Android Studio.
3. Allow Gradle sync to download Android Gradle Plugin 8.7.3 and Gradle 8.9.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

This workspace did not have the Android SDK or Gradle installed, so an APK could not be compiled here. The source project is provided instead.

## First-run setup on the phone

1. Install the APK you build.
2. Open Nexas Safe.
3. Tap **ENABLE ACCESSIBILITY SERVICE**, find Nexas Safe, and enable it. Android will show the service's access warning because it must read visible UI text to perform local keyword checks.
4. Optionally enable **Device Admin**. This adds friction to ordinary uninstalling, but it is not tamper-proof and is not required for keyword checks.
5. Start Focus Mode and edit the comma-separated app package IDs as needed.

## Important platform limits

- Keyword matching only sees text exposed by other apps through Accessibility. It cannot reliably inspect images, video frames, canvas-rendered pages, inaccessible views, or encrypted content. It is a best-effort filter, not a complete adult-content detector.
- A matching keyword can create false positives. The built-in list uses higher-intent phrases to reduce that risk.
- Focus Mode enforcement requires the Accessibility Service to remain enabled. Android lets the device owner disable the service, revoke Device Admin, force-stop the app, or uninstall it. Ordinary Device Admin does not provide absolute uninstall prevention. Device Owner provisioning is a separate managed-device setup and is intentionally not silently enabled.
- The app has no internet permission. It does not upload screen content.
- Package-based app blocking is configured using Android package IDs, not display names. The defaults include Instagram, TikTok, YouTube, Facebook and X; edit the list for your device.

## Project details

- Package: `com.nexas.safe`
- Language: Java
- Minimum Android version: Android 8.0 (API 26)
- Compile SDK: 35
- Target SDK: 34
